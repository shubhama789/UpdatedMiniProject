package com.cg.insurance.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.cg.insurance.bean.AgentUserBean;
import com.cg.insurance.bean.ClaimBean;
import com.cg.insurance.bean.PolicyBean;
import com.cg.insurance.bean.UserBean;
import com.cg.insurance.exception.InsuranceClaimException;

public interface IInsuranceDAO {
	//int getPolicy_Number(InsuranceClaimBean insuranceClaimBean) throws SQLException, InsuranceClaimException;

	String checkAccess(UserBean userbean) throws IOException, SQLException, InsuranceClaimException;

	void addUser(UserBean userbean) throws InsuranceClaimException, IOException;

	List<ClaimBean> viewAllClaims(String name) throws InsuranceClaimException, IOException, SQLException;

	List<PolicyBean> viewAllPolicy(String name) throws IOException, InsuranceClaimException, SQLException;

	List<AgentUserBean> fetchUsers(String name) throws IOException, InsuranceClaimException, SQLException;

	
}
